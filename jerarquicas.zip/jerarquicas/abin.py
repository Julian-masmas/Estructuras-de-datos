from random import random
from jerarquicas.nodos import Nodo_ArbolBin
#if __name__ == "__main__" and __package__ is None:
 #   from nodos import Nodo_ArbolBin
#else:
 #    from jerarquicas.nodos import Nodo_ArbolBin
     
class ArbolBin:
    def __init__(self) -> None:
        self.raiz = None

    def adicionar(self, nueva_clave) -> bool:
        self.raiz = self.__adicionar(self.raiz, nueva_clave)

    def __adicionar(self, sub_arbol, nueva_clave):      
        if not sub_arbol:
            sub_arbol = Nodo_ArbolBin(nueva_clave)
        elif random() <= 0.5: #adicionar por izquierda
            nodo_izq = self.__adicionar(sub_arbol.izq, nueva_clave)
            sub_arbol.izq = nodo_izq
        else: #adicionar por derecha
            # nodo_der = self.__adicionar(sub_arbol.der, nueva_clave)    
            sub_arbol.der = self.__adicionar(sub_arbol.der, nueva_clave)           
        return sub_arbol

    
        